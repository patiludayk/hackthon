import sys, os, random
from datetime import datetime, timedelta
import yaml
from jinja2 import Environment, FileSystemLoader

def load_client_profiles(path):
    with open(path, 'r') as f:
        return yaml.safe_load(f)['clients']

def generate_swap_trade(client, scenario):
    trade_date = datetime.today().date()
    start_date = trade_date + timedelta(days=2)
    end_date = start_date + timedelta(days=365 * scenario['tenor_years'])

    trade = {
        "trade_date": trade_date.isoformat(),
        "party1": {
            "party_id": "party1",
            "party_identifier": client["lei"],
            "party_name": client["name"],
            "trade_id": f"{client['name'].replace(' ', '')}_{random.randint(1000, 9999)}",
            "trade_scheme": client["trade_scheme"]
        },
        "party2": {
            "party_id": "party2",
            "party_identifier": scenario["counterparty_lei"],
            "party_name": scenario["counterparty_name"],
            "trade_id": f"{scenario['counterparty_name'].replace(' ', '')}_{random.randint(1000, 9999)}",
            "trade_scheme": scenario["trade_scheme"]
        },
        "swap_streams": []
    }

    for stream in scenario['streams']:
        trade["swap_streams"].append({
            "payer": stream["payer"],
            "receiver": stream["receiver"],
            "date_id": f"{stream['type']}Dates",
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "freq_multiplier": stream["frequency"][0],
            "freq_unit": stream["frequency"][1],
            "roll_day": start_date.day,
            "notional": stream["notional"],
            "currency": stream["currency"],
            "type": stream["type"],
            "floating_index": stream.get("floating_index"),
            "index_tenor": stream.get("index_tenor", 6),
            "fixed_rate": stream.get("fixed_rate", 0.0),
            "day_count": stream["day_count"]
        })

    return trade

def main(template_path, profile_path, output_dir, count):
    clients = load_client_profiles(profile_path)

    env = Environment(loader=FileSystemLoader(os.path.dirname(template_path)))
    template = env.get_template(os.path.basename(template_path))

    os.makedirs(output_dir, exist_ok=True)

    for i in range(int(count)):
        client = random.choice(clients)
        scenario = random.choice(client["scenarios"])
        trade = generate_swap_trade(client, scenario)

        filename = f"{trade['party1']['party_name'].replace(' ', '')}_swap_{i+1}.xml"
        with open(os.path.join(output_dir, filename), 'w') as f:
            f.write(template.render(trade=trade))

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
