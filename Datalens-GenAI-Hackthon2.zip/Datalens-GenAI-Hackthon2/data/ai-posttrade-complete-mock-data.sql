-- Counterparty Data with KYC Details Insert Statements
INSERT INTO Counterparty (CounterpartyID, Name, Country, KYCStatus, KYCCheckDate, RiskRating, KYCExpiryDate) VALUES
(1, 'Alpha Investments', 'USA', 'Verified', '2024-10-01', 'Low', '2025-10-01'),
(2, 'Beta Traders', 'UK', 'Pending', NULL, 'Medium', NULL),
(3, 'Gamma Holdings', 'Germany', 'Verified', '2024-09-20', 'High', '2025-09-20'),
(4, 'Delta Partners', 'Singapore', 'Failed', '2024-08-15', 'High', NULL),
(5, 'Epsilon Ventures', 'France', 'Verified', '2024-10-10', 'Low', '2025-10-10');