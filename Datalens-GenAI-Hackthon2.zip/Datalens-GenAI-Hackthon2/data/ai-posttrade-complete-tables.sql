
--  Asset_Class:  This Table Contains Product Type Mapping with Asset Class (i.e. FX, Equities, Rates, Credits )
CREATE TABLE Asset_Class (
    AssetClassID 	varchar(255),
	AssetClassName 	varchar(255),
	ProductID 		varchar(255),
	ProductName 	varchar(255),
	CreatedDate 	timestamp,
	UpdatedDate 	timestamp,
	CONSTRAINT 		PK_AssetClassID PRIMARY KEY (AssetClassID,ProductID)
);

-- Comments for LLM understanding Asset_Class:  This Table Contains Product Type Mapping with Asset Class (i.e. FX, Equities, Rates, Credits )
-- AssetClassID: A unique alphanumeric identifier assigned to each asset class to distinguish it from others.  
-- AssetClassName: The descriptive name of the asset class, such as Equities, Fixed Income, or Derivatives.  
-- ProductID: A unique alphanumeric identifier assigned to each product, ensuring it can be uniquely identified within the asset class.  
-- ProductName: The descriptive name of the product, such as a specific stock, bond, or derivative instrument.  
-- CreatedDate: The timestamp indicating when the record for the asset class and product was initially created in the database.  
-- UpdatedDate: The timestamp indicating the most recent update to the record for the asset class and product, reflecting any changes made.  
-- PK_AssetClassID: The primary key constraint that ensures each combination of AssetClassID and ProductID is unique, preventing duplicate records.  
  


-- Comments for LLM understanding for Party Details: This table contains counerparty and legal entity details. 
CREATE TABLE Party (
    CounterParty_ID 					varchar(255),
	CounterParty_Name 					varchar(255),
	CounterParty_Type 					varchar(255),
	CounterParty_Parent 				varchar(255),
	CounterParty_Location 				varchar(255),
	CounterParty_CountryOfOperation 	varchar(255),
	CONSTRAINT PK_CounterParty_ID PRIMARY KEY (CounterParty_ID)
);


-- Comments for LLM understanding for Party Details: This table contains counerparty and legal entity details.  
-- CounterParty_ID: A unique alphanumeric identifier assigned to each counterparty to distinguish it from others.  
-- CounterParty_Name: The name of the counterparty, which can be an individual, company, or organization.  
-- CounterParty_Type: The type of counterparty, indicating whether it is an individual, organization, or other entity.  
-- CounterParty_Parent: A unique alphanumeric identifier for the parent entity of the counterparty, if applicable, used to establish hierarchical relationships.  
-- CounterParty_Location: The geographical location of the counterparty, such as a city or region.  
-- CounterParty_CountryOfOperation: The country where the counterparty primarily conducts its operations, described by an alphanumeric code.  
-- PK_CounterParty_ID: The primary key constraint that ensures each CounterParty_ID is unique, preventing duplicate records.  













-- Trades Table: This table contains Trade Related Details alongwith its lifecycle. 
CREATE TABLE Trades (
    TradeID 				varchar(255),
	TradeVersion 			Numeric,
	TradeDate 				timestamp,
	TradeSettlementDate 	timestamp,
	TradeSettlementStatus 	varchar(255),
	TradeClearingStatus 	varchar(255),
	TradeStatus 			varchar(255),
	TradeType 			varchar(255),
	TradeCurrency 			varchar(255),
	TradeNotional 			Numeric,
	TradeQuantity 			Numeric,
	TradePrice 				Numeric,
	TradeCounterParty_Id 	varchar(255), 
	Constraint fk_TradeCounterParty FOREIGN KEY (TradeCounterParty_Id) REFERENCES Party (CounterParty_ID),
	TradeLegalEntity 		varchar(255),
	TradeValueDate 			timestamp,
	TradeAssetClassID 		varchar(255),
	TradeProductID 			varchar(255),
	Constraint fk_AssetClassID_ProductID FOREIGN KEY (TradeAssetClassID,TradeProductID) REFERENCES Asset_Class (AssetClassID,ProductID),
	TradeProductName 		varchar(255),
	CONSTRAINT PK_TradeId_TradeVersion PRIMARY KEY (TradeID,TradeVersion)
);
                          		

-- Comments for LLM understanding For Trades Table: This table contains Trade Related Details alongwith its lifecycle.
-- TradeID: A unique alphanumeric identifier assigned to each trade to distinguish it from others.  
-- TradeVersion: A numeric value representing the version of the trade, used to track changes or amendments to the original trade.  
-- TradeDate: The date and time when the trade transaction was executed, recorded for auditing and tracking purposes.  
-- TradeSettlementDate: The date and time when the trade is expected to be settled, indicating when the assets will be exchanged.  
-- TradeSettlementStatus: The current status of the trade settlement process, such as Settled or Pending, indicating whether the settlement has been completed.  
-- TradeClearingStatus: The status of the trade clearing process, such as Cleared or Unclear, indicating whether the trade has been processed through the clearinghouse.  
-- TradeStatus: The current state of the trade, such as Active or Cancelled, indicating whether the trade is still valid or has been nullified.  
-- TradeType: The classification of the trade action, such as Buy, Sell, or Short, indicating the nature of the transaction.  
-- TradeCurrency: The currency in which the trade is denominated, represented by an alphanumeric code (e.g., USD, EUR).  
-- TradeNotional: The notional or total value of the trade, expressed in numeric form.  
-- TradeQuantity: The total number of units of the asset being traded, expressed in numeric form.  
-- TradePrice: The price at which each unit of the asset is traded, expressed in numeric form.  
-- TradeCounterParty_Id: A unique alphanumeric identifier for the counterparty involved in the trade, used to link to the Party table.  
-- fk_TradeCounterParty: A foreign key constraint linking the TradeCounterParty_Id to the CounterParty_ID in the Party table, ensuring referential integrity.  
-- TradeLegalEntity: The legal entity responsible for the trade, identified by an alphanumeric code.  
-- TradeValueDate: The date when the value of the trade is realized or becomes effective, recorded for financial and accounting purposes.  
-- TradeAssetClassID: A unique alphanumeric identifier for the asset class of the trade, used to link to the Asset_Class table.  
-- TradeProductID: A unique alphanumeric identifier for the product within the asset class, used to link to the Asset_Class table.  
-- fk_AssetClassID_ProductID: A foreign key constraint linking the TradeAssetClassID and TradeProductID to the AssetClassID and ProductID in the Asset_Class table, ensuring referential integrity.  
-- TradeProductName: The descriptive name of the product being traded, such as a specific stock or bond.  
-- PK_TradeId_TradeVersion: The primary key constraint that ensures each combination of TradeID and TradeVersion is unique, preventing duplicate records.  






				
								
-- Comments for LLM understanding Risk  -- This table contains Risk Factor to be considered to calculate risk at trade level for individual value date.:   
CREATE TABLE Risk (
    RiskID 								varchar(255),
	RiskValuationDate 					timestamp,
	RiskValue 							Numeric,
	Constraint fk_TradeId_TradeVersion FOREIGN KEY (RiskTradeID,RiskTradeVersion) REFERENCES Trades (TradeID,TradeVersion),
	RiskTradeID 						varchar(255),
	RiskTradeVersion 					Numeric,
	Risk_CashFlows 						Numeric,
	Risk_DiscountRate 					Numeric,
	Risk_ProbabilityOfRiskOccurrence 	Numeric,
	Risk_TimeHorizon 					varchar(255),
	Risk_ExpectedLoss 					Numeric,
	Risk_Volatility 					Numeric,
	Risk_ScenarioAnalysisParameters 	varchar(255),
	Risk_HedgingCost 					Numeric,
	CONSTRAINT PK_RiskID PRIMARY KEY (RiskID)
);

-- Comments for LLM understanding Risk  -- This table contains Risk Factor to be considered to calculate risk at trade level for individual value date.:  
-- RiskID: A unique alphanumeric identifier assigned to each risk entry to distinguish it from others.  
-- RiskValuationDate: The date and time when the risk was evaluated or assessed, recorded for tracking and auditing purposes.  
-- RiskValue: The quantified value of the risk, expressed in numeric form, representing the potential impact.  
-- RiskTradeID: A unique alphanumeric identifier for the trade associated with this risk, used to link to the Trades table.  
-- RiskTradeVersion: A numeric value representing the version of the associated trade, used to track changes or amendments to the trade.  
-- Risk_CashFlows: The expected cash flows associated with the risk, expressed in numeric form, used for financial analysis.  
-- Risk_DiscountRate: The discount rate applied to the expected cash flows of the risk, expressed in numeric form, used for present value calculations.  
-- Risk_ProbabilityOfRiskOccurrence: The probability that the risk will occur, expressed as a numeric value, used for risk assessment.  
-- Risk_TimeHorizon: The time period over which the risk is assessed, described in an alphanumeric form (e.g., 1 year, 5 years).  
-- Risk_ExpectedLoss: The expected financial loss if the risk occurs, expressed in numeric form, used for risk management.  
-- Risk_Volatility: The measure of the risk's volatility, expressed in numeric form, indicating the variability of the risk value.  
-- Risk_ScenarioAnalysisParameters: Parameters used for scenario analysis of the risk, described in an alphanumeric form, used for stress testing.  
-- Risk_HedgingCost: The cost associated with hedging the risk, expressed in numeric form, used for financial planning.  
-- fk_TradeId_TradeVersion: A foreign key constraint linking the RiskTradeID and RiskTradeVersion to the TradeID and TradeVersion in the Trades table, ensuring referential integrity.  
-- PK_RiskID: The primary key constraint that ensures each RiskID is unique, preventing duplicate records.  
  



				

CREATE TABLE KYC (
    KYC_Id 					varchar(255),
	KYC_Status 				varchar(255),
	KYC_LastUpdate 			timestamp,
	KYC_ValidDate 			timestamp,
	KYC_CounterpartyId  	varchar(255),
	Constraint fk_KYC_CounterpartyId FOREIGN KEY (KYC_CounterpartyId) REFERENCES Party (CounterParty_ID),
	CONSTRAINT PK_KYC_Id PRIMARY KEY (KYC_Id)
);



-- Comments for LLM understanding for KYC details: This table contains KYC details for particular counterparty.  
-- KYC_Id: A unique alphanumeric identifier assigned to each KYC (Know Your Customer) record to distinguish it from others.  
-- KYC_Status: The current status of the KYC process, such as Verified or Pending, indicating whether the counterparty's identity has been confirmed.  
-- KYC_LastUpdate: The date and time when the KYC record was most recently updated, recorded for tracking and auditing purposes.  
-- KYC_ValidDate: The date until which the KYC record is considered valid, indicating when the next review is due.  
-- KYC_CounterpartyId: A unique alphanumeric identifier for the counterparty associated with the KYC record, used to link to the Party table.  
-- fk_KYC_CounterpartyId: A foreign key constraint linking the KYC_CounterpartyId to the CounterParty_ID in the Party table, ensuring referential integrity.  
-- PK_KYC_Id: The primary key constraint that ensures each KYC_Id is unique, preventing duplicate records.  
  

