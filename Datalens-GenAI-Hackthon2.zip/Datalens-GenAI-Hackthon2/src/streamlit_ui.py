from openai import OpenAI, AzureOpenAI
import streamlit as st
from swarm import Swarm
from sql_agents import sql_router_agent
import pandas as pd
import base64

# oai_client = AzureOpenAI(
#                 api_key=os.getenv("AZURE_OPENAI_API_KEY"),
#                 api_version="2024-08-01-preview",
#                 azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
#             )

oai_client = AzureOpenAI(
    api_key="10d3e570e2a642f98871e0a51d110504",
    api_version="2024-08-01-preview",
    azure_endpoint="https://genai-openai-dataailens.openai.azure.com"
)
client = Swarm(client = oai_client)

st.title("DataLens App")

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "How can I help?", "data": False}
    ]
if "response" not in st.session_state:
    st.session_state["response"] = None
if "agent" not in st.session_state:
    st.session_state["agent"] = sql_router_agent
if "show_graph" not in st.session_state:
    st.session_state["show_graph"] = False

messages = st.session_state.messages
for msg in messages:
    if msg["role"] == "assistant":
        st.chat_message("assistant", avatar="../img/Eagle_RGB_Cyan_Large.svg").write(msg["content"])
    else:
        st.chat_message(msg["role"]).write(msg["content"])

def manualQuery(msgs):
    response = client.run(
        agent=st.session_state["agent"],
        messages=msgs,
        context_variables={},
        stream=False,
        debug=False,
    )

    for msg in response.messages:
        if msg["content"] and msg["role"] == "assistant":
            return msg["content"]


def downloadCSV():
    temp_msgs = messages.copy()
    temp_msgs.append({"role": "user", "content": "Return the previous data as a csv with no additional text", "data": False})

    data = manualQuery(temp_msgs)

    with open('data.csv', 'w') as file:
        file.write(data)
    return file


def createGraph():
    temp_msgs = messages.copy()
    temp_msgs.append({"role": "user", "content": "Return the previous data as a json with no additional text", "data": False})

    data = manualQuery(temp_msgs)
    print(data)
    if "json" in data:
        data = data[8:-4]

    df = pd.read_json(data)

    # with st.chat_message("assistant"):
    st.write("Graph")
    with st.form(key="my_form"):
        x = st.selectbox(
            "X-Axis Value",
            options=df.columns,
            help="Select which column refers to your X labels.",
        )
        y = st.multiselect(
            "Y-Axis Value(s)",
            options=df.columns,
            help="Select which column refers to your Y labels.",
        )
        submit_button = st.form_submit_button(label="Generate")

    if not x or not y:
        st.warning("Please select both an **x and y axis**")
        st.stop()

    # st.area_chart(data, x=x, y=y)
    # st.dataframe(data)
    return st.bar_chart(df, x=x, y=y)


if prompt := st.chat_input(placeholder="Enter you query"):
    st.session_state["show_graph"] = False
    messages.append({"role": "user", "content": prompt, "data": False})
    st.chat_message("user").write(prompt)

    response = client.run(
        agent=st.session_state["agent"],
        messages=messages,
        context_variables={},
        stream=False,
        debug=False,
    )
    for msg in response.messages:
        print(msg)
        if msg["content"] and msg["role"] == "assistant":
            st.session_state["response"] = msg["content"]
            st.session_state["agent"] = response.agent

            # is_data = bool(msg["function_call"])
            is_numeric = False
            for i in "0123456789":
                if i in msg["content"]:
                    is_numeric = True
                    break

            with st.chat_message("assistant", avatar="../img/Eagle_RGB_Cyan_Large.svg"):
                messages.append({"role": "assistant", "content": st.session_state["response"], "data": is_numeric})
                st.write(st.session_state["response"])


if messages[-1]["data"]:
    columns = st.columns([1, 1, 1, 1, 1])
    with columns[0]:
        if st.button("Show as Graph"):
            st.session_state["show_graph"] = True
    with columns[1]:
        if st.button("Download CSV"):
            downloadCSV()

if  st.session_state["show_graph"]:
    createGraph()