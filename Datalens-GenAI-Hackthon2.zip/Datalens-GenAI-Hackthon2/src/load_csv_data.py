import sqlite3
import pandas as pd

"""
This script is used to load csv data to the sqlite3 db.

"""


def main():

    load_csv_data('../data/market_trade_data.csv','MarketTradeData')
    load_csv_data('../data/sales_credit_data.csv', 'SalesCreditData')
    load_csv_data('../data/settlement_data.csv', 'SettlementData')



def load_csv_data(csvfile, name):

    # Read the CSV file into a pandas DataFrame
    df = pd.read_csv(csvfile)
    # Create a connection to the SQLite database
    connection = sqlite3.connect('../markets-posttrade-database.db')
    cursor = connection.cursor()

    df.to_sql(name, con=connection, if_exists='append', index=False)
    # Close the database connection
    connection.commit()
    cursor.execute(f"SELECT * FROM {name}")
    feeds = cursor.fetchall()
    for feed in feeds:
        print(feed)

    connection.close()
    print(f"Data inserted successfully into {name}")

if __name__ == "__main__":
    main()