import json
import yaml, os, sys
from jinja2 import Environment, FileSystemLoader
from datetime import datetime, timedelta
import random

def load_profile(profile_path):
    with open(profile_path, 'r') as f:
        return yaml.safe_load(f)["clients"]

def generate_trade(trade_id, client):
#     today =  datetime.today()
#     trade_date = today - timedelta(days=random.randint(2, 60))
    today = client['legs'][0]["start_date"]
    trade_date = today + timedelta(days=random.randint(2, 10))
    end_date = trade_date + timedelta(days=365)
    firstPaymentDate = trade_date + timedelta(days=90)
    trade = {
        "trade_id": trade_id,
        "trade_date": trade_date.strftime("%Y-%m-%d"),
        "legs": client["legs"],
        "party1": {
                        "partyId": client['legs'][0]['payer'],
                        "partyName": client['legs'][0]['payer']
                  },
        "party2": {
                        "partyId": client['legs'][0]['receiver'],
                        "partyName": client['legs'][0]['receiver']
                  }
    }
    trade['legs'][0]['start_date'] = trade_date
    trade['legs'][0]['end_date'] = end_date
    trade['legs'][0]['start_date'] = trade_date
    trade['legs'][0]['end_date'] = end_date
    trade['legs'][1]['start_date'] = trade_date
    trade['legs'][1]['end_date'] = end_date
    trade['legs'][1]['start_date'] = trade_date
    trade['legs'][1]['end_date'] = end_date
    trade['legs'][0]['first_payment_date'] = firstPaymentDate
    trade['legs'][1]['first_payment_date'] = firstPaymentDate
#     print(trade)
    return trade

def render_template(template_path, trade_data):
    env = Environment(loader=FileSystemLoader(searchpath=os.path.dirname(template_path)))
    template = env.get_template(os.path.basename(template_path))
    return template.render(trade=trade_data)

def main(template_path, profile_path, output_dir, count):
    os.makedirs(output_dir, exist_ok=True)
    clients = load_profile(profile_path)
    trades_per_client = int(count) // len(clients)
    for client in clients:
        for i in range(int(trades_per_client)):
            trade_data = generate_trade(i + 20, client)
            fpml = render_template(template_path, trade_data)
#             print(fpml)
            output_file = os.path.join(output_dir, f"{client['client_id']}_trade_{i+20}.xml")
            with open(output_file, 'w') as f:
                f.write(fpml)

if __name__ == "__main__":
    main(*sys.argv[1:5])
