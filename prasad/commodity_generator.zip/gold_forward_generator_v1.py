import yaml, os, sys
from jinja2 import Environment, FileSystemLoader
from datetime import datetime

def load_profile(profile_path):
    with open(profile_path, 'r') as f:
        return yaml.safe_load(f)

def generate_trade(trade_id, client_profile):
    trade = {
        "trade_id": trade_id,
        "trade_date": datetime.today().strftime("%Y-%m-%d"),
        "legs": client_profile["legs"]
    }
    return trade

def render_template(template_path, trade_data):
    env = Environment(loader=FileSystemLoader(searchpath=os.path.dirname(template_path)))
    template = env.get_template(os.path.basename(template_path))
    return template.render(trade=trade_data)

def main(template_path, profile_path, output_dir, count):
    os.makedirs(output_dir, exist_ok=True)
    client_profile = load_profile(profile_path)

    for i in range(int(count)):
        trade_data = generate_trade(i + 1, client_profile)
        fpml = render_template(template_path, trade_data)
        output_file = os.path.join(output_dir, f"{client_profile['client_id']}_trade_{i+1}.xml")
        with open(output_file, 'w') as f:
            f.write(fpml)

if __name__ == "__main__":
    main(*sys.argv[1:5])
