import os
import sys
import yaml
import random
from datetime import datetime, timedelta
from jinja2 import Environment, FileSystemLoader

def generate_trade_data(client, scenario):
    trade_date = random_date(scenario["date_range"]["start"], scenario["date_range"]["end"])
    tenor_days = random.choice(scenario["tenor_days"])
    maturity_date = trade_date + timedelta(days=tenor_days)
    notional = random.randint(*scenario["notional_range"])
    price = round(random.uniform(*scenario["price_range"]), 2)

    return {
        "client_id": client["client_id"],
        "party_id": client["party"]["party_id"],
        "party_name": client["party"]["party_name"],
        "trade_date": trade_date.strftime("%Y-%m-%d"),
        "maturity_date": maturity_date.strftime("%Y-%m-%d"),
        "notional": notional,
        "currency": scenario["currency"],
        "settlement_currency": scenario["settlement_currency"],
        "price": price,
        "settlement_type": scenario["settlement_type"]
    }

def random_date(start, end):
    start_dt = datetime.strptime(start, "%Y-%m-%d")
    end_dt = datetime.strptime(end, "%Y-%m-%d")
    return start_dt + timedelta(days=random.randint(0, (end_dt - start_dt).days))

def main(template_path, profile_path, output_dir, trade_count):
    env = Environment(loader=FileSystemLoader(os.path.dirname(template_path)))
    template = env.get_template(os.path.basename(template_path))

    with open(profile_path, 'r') as f:
        profiles = yaml.safe_load(f)["clients"]

    os.makedirs(output_dir, exist_ok=True)

    for i in range(trade_count):
        client = random.choice(profiles)
        scenario = random.choice(client["scenarios"])
        trade_data = generate_trade_data(client, scenario)
        xml_output = template.render(trade=trade_data)

        output_path = os.path.join(output_dir, f"{trade_data['client_id']}_trade_{i+1}.xml")
        with open(output_path, 'w') as f:
            f.write(xml_output)

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]))
